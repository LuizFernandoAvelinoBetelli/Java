/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lista3;

/**
 *
 * @author Luiz Fernando Betell
 */
public class Cachorro extends Animal {   
    
    public Cachorro(int patas){
        super(patas);
    }
    
    @Override
    public void mover(){
        System.out.println("Cachorro = Corre");
    }
    
    @Override
    public void comer(){
        System.out.println("Cachorro come = Raçao");
    }
    
    @Override
    public void imprimir(){
        System.out.println("Caracteriscas Do cachorro");
        System.out.println("Patas: "+this.patas);
    }
}
