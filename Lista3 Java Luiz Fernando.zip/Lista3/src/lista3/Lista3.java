/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lista3;

/**
 *
 * @author Luiz Fernando Betell
 */
public class Lista3 {

    public static void main(String[] args) {
        
        Animal a;
        
        a = new Cachorro(4);
        a.imprimir();
        a.mover();
        a.comer();
       
        System.out.println("=============================");
        
        a = new Ave(2);
        a.imprimir();
        a.mover();
        a.comer();
        
    }
    
}
