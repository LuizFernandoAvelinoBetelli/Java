/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lista3;

/**
 *
 * @author Luiz Fernando Betell
 */
public class Ave extends Animal{

    public Ave(int patas) {
        super(patas);
    }
     
    @Override
    public void mover(){
        System.out.println("Ave = Voa");
    }
    
    @Override
    public void comer(){
        System.out.println("Ave come = Sementes");
    }
    
    @Override
    public void imprimir(){
        System.out.println("Caracteristicas da Ave");
        System.out.println("Patas: "+this.patas);
    }
    
}
