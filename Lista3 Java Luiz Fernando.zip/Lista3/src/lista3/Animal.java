/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lista3;

/**
 *
 * @author Luiz Fernando Betell
 */
public class Animal {
    
    int patas;
    
    public Animal(int patas){
        this.patas = patas;
    }
    
    public void mover(){
   
    }
    
    public void comer(){
    }
    
    public void imprimir(){
        
    }
    
    
    
    
}
