/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aulapolimorfismo;

/**
 *
 * @author f290ti
 */
public class ExtendsAbstract extends Minhaclasseabstrata{

    @Override
    public void texto() {
        System.out.println("Texto");
    }

    @Override
    public void texto1() {
        
    }

    @Override
    public int texto2() {
        return 2;
    }
    
}
