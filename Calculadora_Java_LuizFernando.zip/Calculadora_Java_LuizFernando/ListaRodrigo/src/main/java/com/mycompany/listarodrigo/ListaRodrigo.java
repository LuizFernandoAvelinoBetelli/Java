/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.listarodrigo;

/**
 *
 * @author f290ti
 */
import java.io.*;
import java.util.Scanner;
public class ListaRodrigo {

    public static void main(String[] args) {
       
        float numA, numB, mostrar;
        Scanner ler = new Scanner(System.in);
        
        System.out.println("Informe o primeiro Numero: ");
        numA = ler.nextFloat();
        System.out.println("Informe o segundo Numero: ");
        numB = ler.nextFloat();
        
        funcoescalc calcular = new funcoescalc();
        
        mostrar = calcular.soma(numA, numB);
        System.out.println("Soma: "+mostrar);
        
        mostrar = calcular.subtrai(numA, numB);
        System.out.println("Subtracao: "+mostrar);
        
        mostrar = calcular.mult(numA, numB);
        System.out.println("Multiplicacao: "+mostrar);
        
        mostrar = calcular.divide(numA, numB);
        System.out.println("Divisao: "+mostrar);
        

    }
}
