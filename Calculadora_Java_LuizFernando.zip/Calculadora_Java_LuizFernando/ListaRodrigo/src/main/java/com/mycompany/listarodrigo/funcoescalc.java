/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.listarodrigo;

/**
 *
 * @author f290ti
 */
public class funcoescalc {
    
    public float soma(float numA, float numB){
        float resultado;
        resultado = numA+numB;
        return resultado;
        
    }
    
     public float subtrai (float numA, float numB){
        float resultado;
        resultado = numA-numB;
        return resultado;
        
    }
      public float mult(float numA, float numB){
        float resultado;
        resultado = numA*numB;
        return resultado;
        
    }
       public float divide(float numA, float numB){
        float resultado;
        resultado = numA/numB;
        return resultado;
        
    }
}

