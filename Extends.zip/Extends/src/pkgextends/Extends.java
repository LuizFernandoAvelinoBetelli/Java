/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkgextends;

/**
 *
 * @author f290ti
 */
public class Extends {

    /**
     * @param args the command line arguments
     */
   
    public static void main(String[] args) {
        
    //instanciar o carro
    
    carro c = new carro(1, 4 , "Azul", 4,2);
    
     System.out.println("Airbag: "+c.getAirbag());
     System.out.println("Portas: "+c.getPortas());
        
      c.imprimir();
        System.out.println("======================");
      c.setRodas(5);
        
      c.imprimir();
      
        
        
        
    }
    
}
