/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkgextends;

/**
 *
 * @author f290ti
 */
       public class carro extends veiculoheranca{
           //atributos
           private int portas;
           private int airbag;
                 
       public carro(int motor, int rodas, String cor, int portas, int airbag){
           
           //acessa o construtor da SUPERCLASSE ( veiculoheranca)
           
           super(motor, rodas, cor);
           this.portas = portas;
           this.airbag = airbag;           
       }

    carro() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
       public void setPortas(int portas){
           this.portas = portas;
           
       }
       
       public void setAirbag(int airbag){
           this.airbag = airbag;
       }
       
       public int getAirbag(){
           return airbag;
       }
       public int getPortas(){
           return portas;
       }
           
       @Override
       public void imprimir(){
           super.imprimir();//imprimir todos os atributos de veiculo 
           
           System.out.println("Portas: "+portas);
           System.out.println("Airbag: "+airbag);
           
       }
       @Override
       public void setRodas(int rodas){
           super.setRodas(rodas);
           
       }
       }

