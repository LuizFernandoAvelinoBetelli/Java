/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lista2;

/**
 *
 * @author Luiz Fernando Betell
 */
import java.io.*;
import java.util.Scanner;

public class Lista2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int num;
        
        Scanner mostrar = new Scanner(System.in);
        
     //Exercicio 1   
        System.out.println("Informe um numero: ");
        num = mostrar.nextInt();
        
        if(num < 20  ){
            System.out.println("O valor nao pode ser mostrado");    
        }else{
            System.out.println("O valor e "+num);
        }
        
      
     //Exercicio 2   
    int []num1 = new int[2];
    int somar;
    
     
    for(int i=0; i<2; i++){
            System.out.println("Informe um numero: ");
            num1[i] = mostrar.nextInt();                     
        } 
      somar = num1[0] + num1[1];
      
      if(somar >10){
          System.out.println(somar);
      }else{
          System.out.println("O numero nao pode ser mostrado");
      }
       
      //Exercicio 3
      
      double calc;       
        
        if(num>0){
            calc = Math.sqrt(num);
            System.out.println("A raiz quadrada do numero e: "+calc);
        }else{
            calc = Math.pow(num, 2);
            System.out.println("O quadrado do numero e: "+calc);
        }  
    }
    
      //Exercicio 4
        public static void ex4(int num){
        if((num%3)==0){
            System.out.println("O numero "+num+" e multiplo de 3");
        }else{
            System.out.println("O numero "+num+" nao e multiplo de 3");
        } 
    }
        //Exercicio 5
        public static void ex5(int num){
        if((num%3)==0){
            System.out.println("O numero "+num+" e divisivel por 3");
        }
        else{
            if((num%7)==0){
                System.out.println("O numero "+num+" e divisivel por 7");
            }else{
                System.out.println("O numero "+num+" nao e divisivel nem por 3 e nem por 7");
            }
        }
    }
        //Exercicio 6   
        public static void ex6(int num){
        if(((num%2)==0) && ((num%5)==0) && ((num%10)==0)){
            System.out.println("O numero "+num+" e divisivel por 2,5 e 10");
        }else{
            System.out.println("O numero "+num+" nao e divisivel por 2, 5 e 10");
        }
    }
    
}
    
